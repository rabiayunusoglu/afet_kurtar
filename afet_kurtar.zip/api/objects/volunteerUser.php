<?php
class VolunteerUser{
 
    // database connection and table name
    private $conn;
    private $table_name = "volunteerUser";
 
    // object properties
    public $volunteerID;
    public $volunteerName;
    public $role;
    public $assignedTeamID;
    public $latitude;
    public $longitude;
    public $address;
    public $isExperienced;
    public $haveFirstAidCert;
    public $requestedSubpart;
    public $responseSubpart;
    public $locationTime;
    public $tc;
    public $tel;
    public $birthDate;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }

    function read(){
        // select all query
        $query = "SELECT
                    volunteerID, volunteerName, `role`, assignedTeamID, latitude, longitude, `address`, isExperienced, haveFirstAidCert, requestedSubpart, responseSubpart, locationTime, tc,tel, birthDate
                FROM
                    " . $this->table_name . " ";
     
        // prepare query statement
        $stmt = $this->conn->prepare($query);
     
        // execute query
        $stmt->execute();
     
        return $stmt;
    }

    function create(){
 
        // query to insert record
        $query = "INSERT INTO
                    " . $this->table_name . "
                SET
                volunteerID=:volunteerID, volunteerName=:volunteerName, `role`=:role, assignedTeamID=:assignedTeamID, latitude=:latitude, longitude=:longitude, `address`=:address, isExperienced=:isExperienced, haveFirstAidCert=:haveFirstAidCert, requestedSubpart=:requestedSubpart, responseSubpart=:responseSubpart, locationTime=:locationTime, tc=:tc,tel=:tel, birthDate=:birthDate";
     
        // prepare query
        $stmt = $this->conn->prepare($query);
     
        // sanitize
        $this->volunteerID=htmlspecialchars(strip_tags($this->volunteerID));
        $this->volunteerName=htmlspecialchars(strip_tags($this->volunteerName));
        $this->role=htmlspecialchars(strip_tags($this->role));
        $this->assignedTeamID=htmlspecialchars(strip_tags($this->assignedTeamID));
        $this->latitude=htmlspecialchars(strip_tags($this->latitude));
        $this->longitude=htmlspecialchars(strip_tags($this->longitude));
        $this->address=htmlspecialchars(strip_tags($this->address));
        $this->isExperienced=htmlspecialchars(strip_tags($this->isExperienced));
        $this->haveFirstAidCert=htmlspecialchars(strip_tags($this->haveFirstAidCert));
        $this->requestedSubpart=htmlspecialchars(strip_tags($this->requestedSubpart));
        $this->responseSubpart=htmlspecialchars(strip_tags($this->responseSubpart));
        $this->locationTime=htmlspecialchars(strip_tags($this->locationTime));
        $this->tc=htmlspecialchars(strip_tags($this->tc));
        $this->tel=htmlspecialchars(strip_tags($this->tel));
        $this->birthDate=htmlspecialchars(strip_tags($this->birthDate));
    
     
        // bind values
        $stmt->bindParam(":volunteerID", $this->volunteerID);
        $stmt->bindParam(":volunteerName", $this->volunteerName);
        $stmt->bindParam(":role", $this->role);
        $stmt->bindParam(":assignedTeamID", $this->assignedTeamID);
        $stmt->bindParam(":latitude", $this->latitude);
        $stmt->bindParam(":longitude", $this->longitude);
        $stmt->bindParam(":address", $this->address);
        $stmt->bindParam(":isExperienced", $this->isExperienced);
        $stmt->bindParam(":haveFirstAidCert", $this->haveFirstAidCert);
        $stmt->bindParam(":requestedSubpart", $this->requestedSubpart);
        $stmt->bindParam(":responseSubpart", $this->responseSubpart);
        $stmt->bindParam(":locationTime", $this->locationTime);
        $stmt->bindParam(":tc", $this->tc);
        $stmt->bindParam(":tel", $this->tel);
        $stmt->bindParam(":birthDate", $this->birthDate);
    
     
        // execute query
        if($stmt->execute()){
            return true;
        }
     
        return false;
         
    }

    function search(){
        // select all query
        $query = "SELECT
                    volunteerID, volunteerName, `role`, assignedTeamID, latitude, longitude, `address`, isExperienced, haveFirstAidCert, requestedSubpart, responseSubpart, locationTime, tc,tel, birthDate
                FROM
                    " . $this->table_name . "
                WHERE
                    (volunteerID = :volunteerID OR :volunteerID = '') 
                    AND (volunteerName = :volunteerName OR :volunteerName = '')
                    AND (`role` = :role OR :role = '')
                    AND (assignedTeamID = :assignedTeamID OR :assignedTeamID = '')
                    AND (latitude = :latitude OR :latitude = '')
                    AND (longitude = :longitude OR :longitude = '')
                    AND (`address` = :address OR :address = '')
                    AND (isExperienced = :isExperienced OR :isExperienced = '')
                    AND (haveFirstAidCert = :haveFirstAidCert OR :haveFirstAidCert = '')
                    AND (requestedSubpart = :requestedSubpart OR :requestedSubpart = '')
                    AND (responseSubpart = :responseSubpart OR :responseSubpart = '')
                    AND (locationTime = :locationTime OR :locationTime = '')
                    AND (tc = :tc OR :tc = '')
                    AND (tel = :tel OR :tel = '')
                    AND (birthDate = :birthDate OR :birthDate = '')";
     
        // prepare query statement
        $stmt = $this->conn->prepare($query);
     

        // sanitize
        $this->volunteerID=htmlspecialchars(strip_tags($this->volunteerID));
        $this->volunteerName=htmlspecialchars(strip_tags($this->volunteerName));
        $this->role=htmlspecialchars(strip_tags($this->role));
        $this->assignedTeamID=htmlspecialchars(strip_tags($this->assignedTeamID));
        $this->latitude=htmlspecialchars(strip_tags($this->latitude));
        $this->longitude=htmlspecialchars(strip_tags($this->longitude));
        $this->address=htmlspecialchars(strip_tags($this->address));
        $this->isExperienced=htmlspecialchars(strip_tags($this->isExperienced));
        $this->haveFirstAidCert=htmlspecialchars(strip_tags($this->haveFirstAidCert));
        $this->requestedSubpart=htmlspecialchars(strip_tags($this->requestedSubpart));
        $this->responseSubpart=htmlspecialchars(strip_tags($this->responseSubpart));
        $this->locationTime=htmlspecialchars(strip_tags($this->locationTime));
        $this->tc=htmlspecialchars(strip_tags($this->tc));
        $this->tel=htmlspecialchars(strip_tags($this->tel));
        $this->birthDate=htmlspecialchars(strip_tags($this->birthDate));
    
     
        // bind values
        $stmt->bindParam(":volunteerID", $this->volunteerID);
        $stmt->bindParam(":volunteerName", $this->volunteerName);
        $stmt->bindParam(":role", $this->role);
        $stmt->bindParam(":assignedTeamID", $this->assignedTeamID);
        $stmt->bindParam(":latitude", $this->latitude);
        $stmt->bindParam(":longitude", $this->longitude);
        $stmt->bindParam(":address", $this->address);
        $stmt->bindParam(":isExperienced", $this->isExperienced);
        $stmt->bindParam(":haveFirstAidCert", $this->haveFirstAidCert);
        $stmt->bindParam(":requestedSubpart", $this->requestedSubpart);
        $stmt->bindParam(":responseSubpart", $this->responseSubpart);
        $stmt->bindParam(":locationTime", $this->locationTime);
        $stmt->bindParam(":tc", $this->tc);
        $stmt->bindParam(":tel", $this->tel);
        $stmt->bindParam(":birthDate", $this->birthDate);
     
        // execute query
        $stmt->execute();
     
        return $stmt;
    }

    function delete(){
        // delete query
        $query = "DELETE FROM " . $this->table_name . " WHERE volunteerID = :volunteerID";
    
        // prepare query
        $stmt = $this->conn->prepare($query);
    
        // sanitize
        $this->volunteerID=htmlspecialchars(strip_tags($this->volunteerID));
    
        // bind id of record to delete
        $stmt->bindParam(":volunteerID", $this->volunteerID);
    
        // execute query
        if($stmt->execute()){
            return true;
        }
    
        return false;
    }

    // update the volunteeruser
    function update(){
  
        // update query
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    volunteerName=:volunteerName, `role`=:role, assignedTeamID=:assignedTeamID, latitude=:latitude, longitude=:longitude, `address`=:address, isExperienced=:isExperienced, haveFirstAidCert=:haveFirstAidCert, requestedSubpart=:requestedSubpart, responseSubpart=:responseSubpart, locationTime=:locationTime, tc=:tc, tel=:tel, birthDate=:birthDate
                WHERE
                    volunteerID=:volunteerID";
    
        // prepare query statement
        $stmt = $this->conn->prepare($query);
  
    
        // sanitize
        $this->volunteerID=htmlspecialchars(strip_tags($this->volunteerID));
        $this->volunteerName=htmlspecialchars(strip_tags($this->volunteerName));
        $this->role=htmlspecialchars(strip_tags($this->role));
        $this->assignedTeamID=htmlspecialchars(strip_tags($this->assignedTeamID));
        $this->latitude=htmlspecialchars(strip_tags($this->latitude));
        $this->longitude=htmlspecialchars(strip_tags($this->longitude));
        $this->address=htmlspecialchars(strip_tags($this->address));
        $this->isExperienced=htmlspecialchars(strip_tags($this->isExperienced));
        $this->haveFirstAidCert=htmlspecialchars(strip_tags($this->haveFirstAidCert));
        $this->requestedSubpart=htmlspecialchars(strip_tags($this->requestedSubpart));
        $this->responseSubpart=htmlspecialchars(strip_tags($this->responseSubpart));
        $this->locationTime=htmlspecialchars(strip_tags($this->locationTime));
        $this->tc=htmlspecialchars(strip_tags($this->tc));
        $this->tel=htmlspecialchars(strip_tags($this->tel));
        $this->birthDate=htmlspecialchars(strip_tags($this->birthDate));
    
     
        // bind values
        $stmt->bindParam(":volunteerID", $this->volunteerID);
        $stmt->bindParam(":volunteerName", $this->volunteerName);
        $stmt->bindParam(":role", $this->role);
        $stmt->bindParam(":assignedTeamID", $this->assignedTeamID);
        $stmt->bindParam(":latitude", $this->latitude);
        $stmt->bindParam(":longitude", $this->longitude);
        $stmt->bindParam(":address", $this->address);
        $stmt->bindParam(":isExperienced", $this->isExperienced);
        $stmt->bindParam(":haveFirstAidCert", $this->haveFirstAidCert);
        $stmt->bindParam(":requestedSubpart", $this->requestedSubpart);
        $stmt->bindParam(":responseSubpart", $this->responseSubpart);
        $stmt->bindParam(":locationTime", $this->locationTime);
        $stmt->bindParam(":tc", $this->tc);
        $stmt->bindParam(":tel", $this->tel);
        $stmt->bindParam(":birthDate", $this->birthDate);
    
     
        // execute query
        if($stmt->execute()){
            return true;
        }
     
        return false;
	}
}
?>