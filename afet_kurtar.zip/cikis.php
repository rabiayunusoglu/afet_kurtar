<?php
session_destroy();
header("location: https://afetkurtar.site/");
?>