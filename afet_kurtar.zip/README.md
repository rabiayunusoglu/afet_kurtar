## AFET KURTAR
Bil496 Bitirme Projesi - Team Yakamoz <br />
Ömer Parlaktürk <br />
Rabia Yunusoglu <br />
Derda Kaymak <br />
Okan Erdoğan <br />
Muhammed Tarık Dinçer <br />

